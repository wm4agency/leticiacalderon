<article class="container">
  <h1>Semblanza</h1>
  <ul>
    <li>
      <h2>Trayectoria Legislativa</h2>
      <ul>
        <li>Diputada Local por el Dtto. XXVII en el Congreso del Estado de México (2015-2018).</li>
        <li>Diputada Federal en la LXII Legislatura (2012-2015).</li>
      </ul>
    </li>
    <li>
      <h2>Trayectoria Partidista</h2>
      <ul>
        <li>Consejera Política Nacional.</li>
        <li>Consejera Política Estatal en el C.D.E. del PRI Estado de México.</li>
        <li>Consejera Política Municipal C.D.M. del PRI Valle de Chalco Solidaridad.</li>
        <li>Presidenta Proyecto Político Mexiquense.</li>
        <li>Presidenta Fundadora del Proyecto Nacional por y para México, A.C.</li>
        <li>Secretaria de Programa de Acción y Gestión Social del Comité Directivo Estatal del PRI Estado de México (2006-2011).</li>
        <li>Presidenta Comité Directivo Municipal del PRI (2002-2003).</li>
      </ul>
    </li>
    <li>
      <h2>Preparación Académica</h2>
      <ul>
        <li>Contaduría Pública. Escuela Superior de Comercio y Administración, IPN.</li>
        <li>Maestría en Responsabilidad Social. Universidad Anáhuac Norte.</li>
        <li>Seminario Ejecutivo de Liderazgo y Gobernanza, “Construyendo Viabilidad Política”.The George Washington University.</li>
        <li>Taller de Gerencia Política de Proyectos de Cambio. The George Washington University.</li>
      </ul>
    </li>
  </ul>
</article>
