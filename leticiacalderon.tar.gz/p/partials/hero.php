<div class="container">
  <figure class="leticia"></figure>
  <?php include getcwd()."/p/components/leticiaCalderon.php"; ?>
  <p class="slogan">Gobernar bien, <strong>es <b>Posible</b></strong></p>
  <?php include getcwd()."/p/components/votaPRI.php"; ?>
</div>
