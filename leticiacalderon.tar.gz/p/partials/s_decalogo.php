<article class="container">
  <h1>Decálogo de Compromisos Prioritarios</h1>
  <ol>
    <li>Programa Integral de <strong>Pavimentación</strong>.</li>
    <li>Aumento del parque vehicular de <strong>camiones recolectores</strong> de basura para todas las colonias.</li>
    <li>Implementación de <strong>cámaras de vigilancia con botones de pánico</strong>.</li>
    <li><strong>Simplificar los trámites</strong> administrativos para aperturar un negocio.</li>
    <li><strong>Línea Telefónica Directa</strong> con la Presidenta Municipal.</li>
    <li>Recuperación de todos los <strong>espacios deportivos</strong> del municipio.</li>
    <li>Construcción de un <strong>Hospital para los Adultos Mayores</strong> y un <strong>Centro de Atención Integral para personas con Discapacidad</strong>.</li>
    <li>Ampliación y mejoría en la calidad de los servicios médicos que ofrece el <strong>Hospital General Fernando Quiroz</strong>, así como el abasto de medicamentos en todos los hospitales y centros de salud municipales.</li>
    <li>Línea veinticuatro horas para la denuncia de <strong>violencia intrafamiliar y de género</strong>.</li>
    <li>Rehabilitación del <strong>Panteón Municipal</strong>.</li>
  </ol>
</article>
