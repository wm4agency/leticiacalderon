<figure class="calderon">
  <h1>Leticia <b>Calderón</b></h1>
  <h2><span  class="hidden"> ,</span>candidata a <strong>Presidenta Municipal</strong></h2>
  <h3><span class="hidden">,Municipio de </span>Valle de Chalco Solidaridad</h3>
</figure>
