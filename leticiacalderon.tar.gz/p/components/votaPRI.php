<figure class="votaPRI">
  <figcaption><p><b>Vota</b> 1 de Julio</p></figcaption>
  <img src="<?php include "priEdoMex-logo.php" ?>" />
</figure>
