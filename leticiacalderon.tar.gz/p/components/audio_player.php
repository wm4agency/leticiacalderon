<div class="wm4_audioplayer">
  <header>
    <h1>Conoce las propuestas de Leticia</h1>
    <h2>¡En tu ritmo favorito!</h2>
  </header>
  <div class="jouele-playlist" data-space-control="true" data-repeat="true">
    <p><a href="assets/audios/tu_ya_sabes_por_quien_votar-reggaeton.mp3" class="jouele" data-length="4:23">Tu ya sabes por quien votar <span>- reggaeton</span></a></p>
    <p><a href="assets/audios/ella_es_leticia-banda.mp3" class="jouele" data-length="3:19">Ella es Leticia  <span>- banda</span></a></p>
    <p><a href="assets/audios/oyeme_bien-salsa.mp3" class="jouele" data-length="4:00">Óyeme bien <span>- salsa</span></a></p>
    <p><a href="assets/audios/con_ganas-cumbia.mp3" class="jouele" data-length="4:09">Con ganas <span>- cumbia</span></a></p>
  </div>
</div>
