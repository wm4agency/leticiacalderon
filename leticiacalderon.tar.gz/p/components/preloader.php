<div id="preloader">
  <div class="wrapper">
    <img src="" />
    <h1>Un Mejor Gobierno <strong>es Posible</strong></h1>
  </div>
</div>
